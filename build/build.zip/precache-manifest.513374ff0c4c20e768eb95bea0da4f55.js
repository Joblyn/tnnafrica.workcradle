self.__precacheManifest = [
  {
    "revision": "bba7fcc126715e471bab",
    "url": "/static/css/main.95930c81.chunk.css"
  },
  {
    "revision": "bba7fcc126715e471bab",
    "url": "/static/js/main.bba7fcc1.chunk.js"
  },
  {
    "revision": "1646dadf224d616932e7",
    "url": "/static/css/1.28e460b8.chunk.css"
  },
  {
    "revision": "1646dadf224d616932e7",
    "url": "/static/js/1.1646dadf.chunk.js"
  },
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "748ece61a762c13104a927fcad6a24e9",
    "url": "/static/media/portrait.748ece61.jpg"
  },
  {
    "revision": "b93e341ace943229adc30b93afd3f63e",
    "url": "/static/media/logo.b93e341a.jpg"
  },
  {
    "revision": "797da2db9d03247830fbf1d4c10caff6",
    "url": "/static/media/bg.797da2db.jpg"
  },
  {
    "revision": "143a3cb413b6efc8d0877de583149092",
    "url": "/index.html"
  }
];